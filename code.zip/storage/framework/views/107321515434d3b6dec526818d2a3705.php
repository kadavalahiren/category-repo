<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-center"><?php echo e(isset($category) ? 'Edit' : 'Create'); ?> Category</h1>
    <form action="<?php echo e(isset($category) ? route('categories.update', $category) : route('categories.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(isset($category)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="row mb-3">
            <label for="name" class="col-md-3 col-form-label">Name:</label>
            <div class="col-md-9">
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e($category->name ?? ''); ?>" required>
            </div>
        </div>

        <div class="row mb-3">
            <label for="parent_id" class="col-md-3 col-form-label">Parent Category:</label>
            <div class="col-md-9">
                <select id="parent_id" name="parent_id" class="form-select">
                    <option value="">None</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($parent->id); ?>" <?php echo e((isset($category) && $category->parent_id == $parent->id) ? 'selected' : ''); ?>>
                            <?php echo e($parent->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="d-flex justify-content-center">
            <button type="submit" class="btn btn-primary">
                <?php echo e(isset($category) ? 'Update' : 'Create'); ?> Category
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\project\TreeExamples\resources\views/category/create.blade.php ENDPATH**/ ?>