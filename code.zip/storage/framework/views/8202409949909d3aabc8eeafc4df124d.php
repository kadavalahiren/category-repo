<ul>
  <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <div class="category_name">
      <span class="name"><?php echo e($subcategory->category_name); ?></span>

    <!-- Action Buttons for Subcategory -->
    <div class="icon add" title="Add" data-id="<?php echo e($subcategory->id); ?>">+</div>
    <div class="icon edit" title="Edit" data-id="<?php echo e($subcategory->id); ?>">✎</div>
    <div class="icon status" title="Status" data-id="<?php echo e($subcategory->id); ?>">✓</div>
    <div class="icon delete" title="Delete" data-id="<?php echo e($subcategory->id); ?>">x</div>

      <?php if($subcategory->subcategories->isNotEmpty()): ?>
        <?php echo $__env->make('category.subcategories', ['subcategories' => $subcategory->subcategories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH E:\wamp\www\project\TreeExamples\resources\views/category/subcategories.blade.php ENDPATH**/ ?>